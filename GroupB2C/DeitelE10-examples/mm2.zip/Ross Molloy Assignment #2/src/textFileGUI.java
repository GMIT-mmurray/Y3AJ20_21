import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class textFileGUI {
    private JTextField textField;
    private JTextArea textArea;
    private JLabel header;
    private JLabel words;
    private JLabel capitalLetters;
    private JLabel numberOfFiveLowerCaseWords;
    private JLabel capitalLetterWords;
    private JLabel numbers;
    private JPanel textFieldPanel;
    private String textFieldName;
    private StringBuffer textFieldContent;
    private static Scanner input;
    private int count = 0;

    public textFileGUI() {
        textField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                textFieldName = textField.getText();
                try
                {
                    input = new Scanner(Paths.get("%s", textFieldName));
                }
                catch (IOException ioException)
                {
                    //printf to see if newline or null characters are included in text field name string, why not working?
                    System.out.println("Input text field name: '" + textFieldName + "'");
                    System.err.println("Error opening file. Terminating.");
                    System.exit(1);
                }

                textFieldContent = new StringBuffer();
                while(input.hasNext()) {
                    textFieldContent.append(" "+input.nextLine());
                }

                textArea.setText(textFieldContent.toString());

                Pattern pattern = Pattern.compile("\\S+");
                Matcher matcher = pattern.matcher(textFieldContent.toString());
                while (matcher.find())
                    count++;
                words.setText("Number of words: " + count);

                count = 0;
                Pattern pattern1 = Pattern.compile("[A-Z]");
                Matcher matcher1 = pattern1.matcher(textFieldContent.toString());
                while (matcher1.find())
                    count++;
                capitalLetters.setText("Number of capital letters: " + count);

                count = 0;
                Pattern pattern2 = Pattern.compile("\\b[a-z]{5}\\b");
                Matcher matcher2 = pattern2.matcher(textFieldContent.toString());
                while (matcher2.find())
                    count++;
                numberOfFiveLowerCaseWords.setText("Number of five lower case words: " + count);

                count = 0;
                Pattern pattern3 = Pattern.compile("\\b[A-Z].*?\\b");
                Matcher matcher3 = pattern3.matcher(textFieldContent.toString());
                while (matcher3.find())
                    count++;
                capitalLetterWords.setText("Number of words with capital letters: " + count);

                count = 0;
                Pattern pattern4 = Pattern.compile("\\d");
                Matcher matcher4 = pattern4.matcher(textFieldContent.toString());
                while (matcher4.find())
                    count++;
                numbers.setText("Number of numbers: " + count);
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                JFrame frame = new JFrame("textFileGUI");
                frame.setContentPane(new textFileGUI().textFieldPanel);
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.pack();
                frame.setVisible(true);
            }
        });
    }
}
